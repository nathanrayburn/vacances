/*
	Nathan Rayburn
	Vers 11.10.18
	Function that transfers the value of the text input 1 to the input 2
*/
function message(){
    let el = document.getElementById('msg1'); //Search for the ID
    let ele = document.getElementById('msg2'); //Search for the ID
    qqch = el.value; //Store the Value of the text input

    if(qqch.length === 0 ){
        alert("Veullez écrire un Message");

    }else{
        ele.value = qqch;
        el.value = '';

    }
    return false;
}