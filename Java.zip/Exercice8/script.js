function All() {
  
  checkB= document.getElementsByName('chk')
  
  for(var i=0, n=checkB.length;i<n;i++) {
  
   checkB[i].checked = true;
 }
return false
}
function None() {
  
  checkB= document.getElementsByName('chk')
  
  for(var i=0, n=checkB.length;i<n;i++) {
  
   checkB[i].checked =false;
 }
 return false
}

function Invert() {
  checkB = document.getElementsByName('chk')
  
  for(var i=0, n=checkB.length;i<n;i++) {
    
    if(checkB[i].checked){
    
      checkB[i].checked =false;
    
    }else{
    
      checkB[i].checked = true;
    
    }
 }
 return false
}
