/*
	Nathan Rayburn
	Vers : 11.10.18
	Function to change the source of the image
*/
function onHover(photo)
{
        document.getElementById("image").src = "img/selec0" + photo + ".jpg";
}
