function ecrire(typetext) {
  var newtext = prompt('Enter New Text Here:');
  var textarea = document.getElementById('text1');
  textarea.textContent += " [<" + typetext + ">" + newtext + "</" + typetext + ">]";
}
