
/*
	Nathan rayburn
	Vers : 11.10.18

	//Function that sends a message in a alert
*/
function sendalert(qqch){
    let el = document.getElementById('msg'); //Search for the ID
    qqch = el.value; //Store the Value of the text input
    
    if(qqch.length === 0 ){
        alert("Veullez écrire un Message");
        return false;
    
    }else{
        alert(qqch); //Put the message in the Alert
    
    }





}