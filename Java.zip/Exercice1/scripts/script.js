
function dire(qqch){
    let el = document.getElementById('msg'); //Search for the ID

    qqch = el.value; //Store the Value of the text input
    alert(qqch); //Put the message in the Alert



}