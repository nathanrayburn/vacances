/*
	Nathan Rayburn
	Vers : 11.10.17
	Function that changes the source of the image in function of the value of the DIV
*/
function setPicture(elem) {

    var image = document.getElementById("images");
    image.src = elem.value;


}