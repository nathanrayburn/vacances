
function chargeselect() {
  var x = document.getElementById("selc2");
  for (var i = 11; i < 100; i++) {
    var option = document.createElement("option");
    option.text = i;
    x.add(option);
  }
}

function writetext() {
  let form = document.querySelector('form');
  let texta = form.elements.textArea,
    min = document.getElementById('selc1'),
    max = document.getElementById('selc2');

  min = min.options[min.selectedIndex].value;
  max = max.options[max.selectedIndex].value;

  for (var i = Number(min); i <= Number(max); i++) {
    texta.textContent += i + ', ';
  }
  texta.textContent = texta.textContent.substring(0, texta.textContent.length - 2);
}
